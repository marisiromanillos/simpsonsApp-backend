const mysql = require("mysql");

const connection = mysql.createConnection({
  user: "marisi_gr",
  password: "Ellabailasola94!",
  host: "locahost",
  port: 3306,
  database: "mrbuildm_demo-simpsons",
});

function asyncMySql(query) {
  return new Promise((resolve, reject) => {
    connection.query(query, (error, results) => {
      if (error) {
        reject(error);
      }
      resolve(results);
    });
  });
}

module.exports = asyncMySql;
